import ListEmp from './components/ListEmp';

function App() {
  return (
    <div className="App">
      <ListEmp />
    </div>
  );
}

export default App;
