import axios from 'axios';

const Employe_Api = "http://localhost:3000/Employees";

class EmpServices {
    getEmployees() {
        return axios.get(Employe_Api);

    }
}

export default new EmpServices;