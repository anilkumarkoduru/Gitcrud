import React, { Component } from 'react';
import EmpServices from '../services/Empservices';
export class ListEmp extends Component {
    constructor(props) {
        super(props);
        this.state = {
            employees: []
        }
    }

    componentDidMount() {
        EmpServices.getEmployees().then((res) => {
            this.setState({ employees: res.data });
        })
    }
    render() {
        return (
            <div>
                <br />
                <h3 className='text-center '> <span className="bg-primary text-white">EMPLOYEE LIST</span></h3>
                <br />
                <div className="row">
                    <table className="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th> Emp Id</th>
                                <th>Emp FirstName</th>
                                <th>Emp LastName</th>
                                <th>EmailId</th>
                                <th>Contact</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>

                            {
                                this.state.employees.map((employee) =>
                                    <tr key={employee.id}>
                                        <td>{employee.id}</td>
                                        <td>{employee.firstName}</td>
                                        <td>{employee.lastName}</td>
                                        <td>{employee.emailId}</td>
                                        <td>{employee.contact}</td>
                                        <td></td>
                                    </tr>
                                )
                            }

                        </tbody>
                    </table>

                </div>
            </div >
        )
    }
}

export default ListEmp;
