import React, { Component } from 'react';

export class UpdateEmp extends Component {
    render() {
        return (
            <div>
                <h1>this is Update Employee</h1>
            </div>
        )
    }
}

export default UpdateEmp;
