import React, { Component } from 'react';

export class FooterComp extends Component {
    render() {
        return (
            <div>
                <h1>this is footer</h1>
            </div>
        )
    }
}

export default FooterComp;
