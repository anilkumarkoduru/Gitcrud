import React, { Component } from 'react';

class CreateEmp extends Component {
    render() {
        return (
            <div>
                    <h1>hello CreateEmp component</h1>
            </div>
        )
    }
}

export default CreateEmp;
