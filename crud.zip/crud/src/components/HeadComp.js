import React, { Component } from 'react';

export class HeadComp extends Component {
    render() {
        return (
            <div>
                <h1>This is Header</h1>
            </div>
        )
    }
}

export default HeadComp;
