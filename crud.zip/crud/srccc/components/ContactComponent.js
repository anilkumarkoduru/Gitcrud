import React, { Component } from 'react';

class ContactComponent extends Component {
    render() {
        return (
            <div>
                <h1>Contact Us Component</h1>
            </div>
        );
    }
}

export default ContactComponent;