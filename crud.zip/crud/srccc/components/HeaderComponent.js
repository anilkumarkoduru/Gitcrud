import React, { Component } from 'react';
import { BrowserRouter as Router,Route,Switch,Link} from 'react-router-dom';
import AboutComponent from './AboutComponent';
import ContactComponent from './ContactComponent';
import HomeComponent from './HomeComponent';
import ListEmployeeComponent from './ListEmployeeComponent';

class HeaderComponent extends Component {
    render() {
        return (
            <Router>
            <div>
              <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
              <ul className="navbar-nav mr-auto">
              <li><Link to={'/home'} className="nav-link">Home</Link></li>
                <li><Link to={'/about'} className="nav-link">About</Link></li>
                <li><Link to={'/contact'} className="nav-link">Contact</Link></li>
                <li><Link to={'/'} className="nav-link"> ListEmployeeComponent </Link></li>                                
              </ul>
              </nav>
              <hr />
              <Switch>
                   <Route exact path='/home' component={HomeComponent} />
                  <Route path='/contact' component={ContactComponent} />
                  <Route path='/about' component={AboutComponent} />                  
                  <Route path="/" exact component={ListEmployeeComponent} ></Route> 
                  <Route path="/employees" exact component={ListEmployeeComponent} ></Route>                                         
              </Switch>
            </div>
          </Router>    

            // <Router>
            // <div>
            //     <header>
            //         <nav className="navbar navbar-expand-md navbar-dark bg-dark">
            //             <Link to='/' className="navbar-brand">REACT CRUD EXAMPLE with AXIOS</Link> 
            //             <div className="collapse navbar-collapse" id="navbarSuppoeredContent">
            //                 <ul className="navbar-nav mr-auto">
            //                     <li className="nav-item">
            //                         <Link to='/' className="nav-link">HOME</Link>
            //                     </li>
            //                     <li className="nav-item">
            //                         <Link to='/about' className="nav-link">ABOUT US</Link>
            //                     </li>
            //                     <li className="nav-item">
            //                         <Link to='/contact' className="nav-link">CONTACT</Link>
            //                     </li>
            //                 </ul>
            //                {/* <h1 className='text-white'>ONLINE</h1>  */}
            //             </div>
            //         </nav>
            //     </header>
            //     <br/>
            // </div>
            // <Switch>
            //         <Route exact path="/" Component={HomeComponent}></Route> 
            //             <Route exact path="/home" Component={HomeComponent}></Route> 
            //             <Route path='/about' Component={AboutComponent}></Route>
            //             <Route path="/contact" Component={ContactComponent}></Route>
            //             {/* <Route path="/employees" component={ListEmployeeComponent} ></Route>
            //   <Route path="/view-employee/:id" component={ViewEmployeeComponent}></Route>
            //   <Route path="/add-employee/:id" component={CreateEmployeeComponent}></Route> */}
            //         </Switch>
            // </Router>
        );
    }
}

export default HeaderComponent;