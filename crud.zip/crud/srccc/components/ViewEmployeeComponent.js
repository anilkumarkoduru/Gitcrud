import React, { Component } from 'react';
import EmployeeService from '../services/EmployeeService';

class ViewEmployeeComponent extends Component {
    constructor(props)
    {
        super(props);
        this.state={
            id:this.props.match.params.id,
            employee:{}
        }
    }
    componentDidMount()
    {
        EmployeeService.getEmployeeById(this.state.id).then(res=>{
            this.setState({employee:res.data});
        })
    }
    render() {
        return (
            <div>
                <div className="card">
                    <div className="text-center">View Employee Details</div>                    
                    <div className="row">
                        <label>EMPLOYEE ID</label>
                        <div>{this.state.employee.id}</div>
                    </div>
                    <div className="row">
                        <label>EMPLOYEE FIRST NAME</label>
                        <div>{this.state.employee.firstName}</div>
                    </div>
                    <div className="row">
                        <label>EMPLOYEE LAST NAME</label>
                        <div>{this.state.employee.lastName}</div>
                    </div>
                    <div className="row">
                        <label>EMPLOYEE EMAIL ID</label>
                        <div>{this.state.employee.emailId}</div>
                    </div>
                    <div className="row">
                        <label>EMPLOYEE CONTACT NUMBER</label>
                        <div>{this.state.employee.contact}</div>
                    </div>
                </div>
            </div>
        );
    }
}

export default ViewEmployeeComponent;