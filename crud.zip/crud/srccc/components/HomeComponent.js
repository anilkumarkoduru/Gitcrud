import React, { Component } from 'react';

class HomeComponent extends Component {
    render() {
        return (
            <div>
                This is Home Component
            </div>
        );
    }
}

export default HomeComponent;