import React, { Component } from 'react';

class AboutComponent extends Component {
    render() {
        return (
            <div>
                <h1>This is About Us Component</h1>
            </div>
        );
    }
}

export default AboutComponent;